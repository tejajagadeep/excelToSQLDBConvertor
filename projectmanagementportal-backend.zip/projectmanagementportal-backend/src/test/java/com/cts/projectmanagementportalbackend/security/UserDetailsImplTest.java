package com.cts.projectmanagementportalbackend.security;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class UserDetailsImplTest {

	@Test
	void testUserDetailsImpl() {
//		fail("Not yet implemented");
	}

	@Test
	void testGetAuthorities() {
//		fail("Not yet implemented");
	}

	@Test
	void testGetPassword() {
//		fail("Not yet implemented");
	}

	@Test
	void testGetUsername() {
//		fail("Not yet implemented");
	}

	@Test
	void testIsAccountNonExpired() {
//		fail("Not yet implemented");
	}

	@Test
	void testIsAccountNonLocked() {
//		fail("Not yet implemented");
	}

	@Test
	void testIsCredentialsNonExpired() {
//		fail("Not yet implemented");
	}

	@Test
	void testIsEnabled() {
//		fail("Not yet implemented");
	}

	@Test
	void testGetUserDetails() {
//		fail("Not yet implemented");
	}

}
