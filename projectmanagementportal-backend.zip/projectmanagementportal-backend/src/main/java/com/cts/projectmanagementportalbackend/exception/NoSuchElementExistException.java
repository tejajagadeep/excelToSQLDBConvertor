package com.cts.projectmanagementportalbackend.exception;

public class NoSuchElementExistException extends RuntimeException {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public NoSuchElementExistException(String msg){
		super(msg);
	}
	
}
