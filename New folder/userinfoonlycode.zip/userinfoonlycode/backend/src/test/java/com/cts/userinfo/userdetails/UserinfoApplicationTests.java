package com.cts.userinfo.userdetails;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserinfoApplicationTests {

	@Test
	void contextLoads() {
	}

}
