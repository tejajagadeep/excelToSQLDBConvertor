

insert into User_Details(user_id, user_fname, user_lname, user_mobile_number, user_email_id, user_created_date) values(1001,'Virendra', 'Shewag',1111111111, 'Viru@gmail.com','2022-07-27');
insert into User_Details(user_id, user_fname, user_lname, user_mobile_number, user_email_id, user_created_date) values(1002, 'Anil', 'Kumble',1111111112, 'Anil@gmail.com','2022-07-27');
insert into User_Details(user_id, user_fname, user_lname, user_mobile_number, user_email_id, user_created_date) values(1003, 'Sachin', 'Tendulkar',1111111113, 'SRT@gmail.com','2022-07-25');
insert into User_Details(user_id, user_fname, user_lname, user_mobile_number, user_email_id, user_created_date) values(1004, 'MS', 'Dhoni',1111111114, 'MS@gmail.com','2022-07-27');
insert into User_Details(user_id, user_fname, user_lname, user_mobile_number, user_email_id, user_created_date) values(1005, 'Yuvaraj', 'Singh',1111111115,'YUVI@gmai.com','2022-07-27');
